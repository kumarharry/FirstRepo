import { Employee } from './../model/employee.model';
import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {
  //  employees: Employee[] = [
  //     {
  //       id: 1,
  //       name: 'Harinder',
  //       gender: 'Male',
  //       email: 'harinder.k@idsil.com',
  //       dateOfBirth: '14/07/1990',
  //       phoneNumber: 1234567890,
  //       PhotoPath: 'assets/images/img1.jpg',
  //       Department: null
  //     },
  //     {
  //       id: 2,
  //       name: 'Yadvinder',
  //       gender: 'Male',
  //       email: 'yad@ps.com',
  //       dateOfBirth: '14/07/1990',
  //       phoneNumber: 1122334455,
  //       PhotoPath: 'assets/images/img2.jpg',
  //       Department: null
  //     },
  //     {
  //       id: 3,
  //       name: 'Yashwant',
  //       gender: 'Male',
  //       email: 'yashi@g.com',
  //       dateOfBirth: '14/07/1990',
  //       phoneNumber: 5566778899,
  //       PhotoPath: 'assets/images/img3.jpg',
  //       Department: null
  //     }
  //   ];
  employees: Employee[];
  employeeToShow: Employee;
  arrEmployeeToShow: Employee[] = [];
  employeeToShowCount = 0;
  blDisplayAll = false;
  constructor(private _employees: EmployeeService) {
  }

  ngOnInit() {
    this.employees = this._employees.GetEmployeeDetails();
     this.employeeToShow = this.employees[this.employeeToShowCount];
     this.arrEmployeeToShow.push(this.employees[this.employeeToShowCount]);
  }
  showNextEmployee(): void {
    this.blDisplayAll =  false;
    this.arrEmployeeToShow = [];
    if (this.employeeToShowCount === this.employees.length - 1) {
      this.employeeToShowCount = 0;
    } else {
      this.employeeToShowCount++;
    }
    this.employeeToShow = this.employees[this.employeeToShowCount];
     this.arrEmployeeToShow.push(this.employees[this.employeeToShowCount]);
  }
  viewAll(): void {
    this.blDisplayAll =  true;
    this.employeeToShowCount = -1;
    this.arrEmployeeToShow = this.employees;
  }
}
