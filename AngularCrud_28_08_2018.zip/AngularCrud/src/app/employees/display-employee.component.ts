import { Employee } from './../model/employee.model';
import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-display-employee',
  templateUrl: './display-employee.component.html',
  styleUrls: ['./display-employee.component.css']
})
export class DisplayEmployeeComponent implements OnInit, OnChanges {
  @Input() emp: Employee;
  constructor() { }

  ngOnInit() {
  }
  ngOnChanges(changes: SimpleChanges) {
    const PreviousValue = <Employee>changes.emp.previousValue;
    const currentValue = <Employee>changes.emp.currentValue;
    // console.log(<Employee>changes.emp.previousValue);
    console.log('Previous value ' + (PreviousValue ? PreviousValue.name : 'Null') + ' Current value ' + currentValue.name) ;
    // console.log(changes.emp);
  }
}
