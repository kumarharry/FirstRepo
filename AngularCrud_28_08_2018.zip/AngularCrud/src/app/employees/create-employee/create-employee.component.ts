import { Employee } from './../../model/employee.model';
import { Component, OnInit } from '@angular/core';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { EmployeeService } from './../employee.service';
import { Router } from '@angular/router';

@Component({
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  employee: Employee = {
    id: null,
    name: null,
    gender: null,
    email: null,
    dateOfBirth: null,
    phoneNumber: null,
    PhotoPath: null,
    Department: 'select',
  };

  isValidImage = false;
  datepickerConfig: Partial<BsDatepickerConfig>;
  gender = 'male';
  empDepartment = [{Id: 1, Name: 'IT'}, {Id: 2, Name: 'HR'}, {Id: 3, Name: 'Payroll'}];
  constructor(private _router: Router, private _employeeService: EmployeeService) {
    this.datepickerConfig = Object.assign({},
      {
        containerClass: 'theme-dark-blue',
        showWeekNumbers: false,
        dateInputFormat: 'DD/MM/YYYY'
      });
  }
  photoPreviewToggle(): void {
    this.isValidImage = !this.isValidImage;
  }
  ngOnInit() {
  }
  saveEmployee(): void {
    this._employeeService.SaveEmployee(this.employee);
    this._router.navigate(['list']);
  }
}
