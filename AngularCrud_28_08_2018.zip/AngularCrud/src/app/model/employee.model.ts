export class Employee {
id: number;
name: string;
gender: string;
email?: string;
dateOfBirth: string;
phoneNumber?: number;
PhotoPath?: string;
Department: string;
}
